puan = 0
print("--- ASYA'YI NE KADAR İYİ TANIYORSUN? ---\n")
print ("1. Soru: Asya'nın en sevdiği renk nedir?\n")
print ("A) Mavi B) Beyaz C) Yeşil D) Narçiçeği\n")
cevap1 = input(".Cevabınız: (A/B/C/D): ").upper()
if cevap1 == "B":
    puan += 20
    print("Doğru cevap! Demek beni dinliyorsun. İşte puanın: ", puan)
elif cevap1 == "C":
    puan += 10
    print("Hep yeşil giymem onu favorim yapmaz ama sana acıdım. İşte puanın: ", puan)
else: 
    puan += 0
    print(" Cidden mi? İşte puanın ezik: ", puan)
print("\n2. Soru: Asya'nın olmak istediği hayvan nedir?\n")
print ("A) Yunus B) Hemşire Köpekbalığı C) Katil Balina D) Kambur Balina\n")
cevap2 = input(".Cevabınız: (A/B/C/D): ").upper()
if cevap2 == "A":
    puan += -10
    print("NE!!! Ben yunuslardan nefret ederim. -10 puan: ", puan)
elif cevap2 == "B" or cevap2 == "C":
    puan += 0
    print("Olsam üzlümezdim ama maalesef asıl istediğim bu değil. 0 puan: ", puan)
else:
    puan += 20
    print("Doğru bildin. Eğer bir hayvan olsaydım alfa kambur balina olurdum. İşte puanın: ", puan)
print("\n3. Soru: Asya son zamanlarda rüyasında en çok neyi görüyor?\n")
print ("A) Evlilik B) Katilden kaçış C) Katil olmak D) Yüksekten düşmek\n")
cevap3 = input(".Cevabınız: (A/B/C/D): ").upper()
if cevap3 == "A":
    puan += 20
    print("Doğru cevap! Nedense hep evlenecek gibi oluyorum. İşte puanın: ", puan)
elif cevap3 == "C":
    puan += 10
    print("Bu aralar diyorum. Beni götünle mi dinliyosun. Neyse al 10 puan: ", puan)
else:
    puan += 0
    print(" Yok bunlar çok klasik: ", puan)
print("\n4. Soru: Asya'nın en sevdiği lise yılı nedir?\n")
print ("A) Hazırlık Sınıfı B) 9. Sınıf C) 10. Sınıf D) 11. Sınıf E) 12. Sınıf\n")
cevap4 = input(".Cevabınız: (A/B/C/D/E): ").upper()
if cevap4 == "A":
    puan += 20
    print("Doğru cevap! Hazırlık C olmazsa olmazdı. İşte puanın: ", puan)
elif cevap4 == "C":
    puan += 0
    print("Ben Berke miyim mk? Neyse işte puanın: ", puan)
else:
    puan += 0
    print("Yok 0 puan: ", puan)
print("\n5. Soru: Asya puanı yetse ne okurdu?\n")
print ("A) Karabük üni otobüs şoförlüğü B) Ytü İstatistik C) Tıp D) İtü Bilgisayar\n")
cevap5 = input(".Cevabınız: (A/B/C/D): ").upper
if cevap5 == "D":
    puan += 20
    print("İtü bilgisayarla cerrahpaşa arasında kaldım en son cerrahpaşa yazdım. İşte puanın: ", puan)
elif cevap5 == "C":
    puan += 10
    print("Çok arada kalınabilirdi ama değil. Yarı puan verdim gitti: ", puan)
else:
    puan += 0
    print("Yok 0 puan: ", puan)
    print("\n Kaç puan aldın bakalım. SS at sikmim: ", puan)
input("\nÇıkmak için Enter tuşuna basın...")